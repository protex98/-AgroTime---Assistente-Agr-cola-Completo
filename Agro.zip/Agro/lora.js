let loraEnabled = false;

// Função para ligar/desligar a rede LoRa
function toggleLoRa() {
    loraEnabled = !loraEnabled;
    document.getElementById('loraStatus').innerText = `Status: ${loraEnabled ? 'Conectado' : 'Desconectado'}`;
    alert(`LoRa ${loraEnabled ? 'ligada' : 'desligada'}`);
}