let aiEnabled = false;

// Função para ligar/desligar a IA
function toggleAI() {
    aiEnabled = !aiEnabled;
    alert(`IA ${aiEnabled ? 'ligada' : 'desligada'}`);
}

// Função para enviar mensagem ao chat
function sendMessage() {
    if (!aiEnabled) {
        alert('A IA está desligada. Ligue-a para interagir.');
        return;
    }

    const userMessage = document.getElementById('chatInput').value;
    if (!userMessage) return;

    // Exibe a mensagem do usuário no chat
    const chatMessages = document.getElementById('chatMessages');
    chatMessages.innerHTML += `<p><strong>Você:</strong> ${userMessage}</p>`;

    // Simula uma resposta da IA
    setTimeout(() => {
        chatMessages.innerHTML += `<p><strong>IA:</strong> Processando sua pergunta...</p>`;
        // Aqui você pode integrar uma API de IA (OpenAI, TensorFlow.js, etc.)
    }, 1000);

    // Limpa o campo de entrada
    document.getElementById('chatInput').value = '';
}