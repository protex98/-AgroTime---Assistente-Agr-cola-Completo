// Função para inicializar o calendário
function initCalendar() {
    const calendarEl = document.getElementById('calendar');
    const calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        events: [
            { title: 'Plantio de Milho', date: '2023-10-15' },
            { title: 'Colheita de Soja', date: '2023-11-20' }
        ],
        headerToolbar: {
            left: 'prev,next today',
            center: 'title',
            right: 'dayGridMonth,timeGridWeek,timeGridDay'
        },
        buttonText: {
            today: 'Hoje',
            month: 'Mês',
            week: 'Semana',
            day: 'Dia'
        },
        locale: 'pt-br' // Tradução para português
    });
    calendar.render();
}

// Função para salvar anotações do solo
function saveSoilNotes() {
    const notes = document.getElementById('soilNotes').value;
    localStorage.setItem('soilNotes', notes);
    alert('Anotações salvas com sucesso!');
}

// Função para carregar anotações do solo
function loadSoilNotes() {
    const notes = localStorage.getItem('soilNotes');
    if (notes) {
        document.getElementById('soilNotes').value = notes;
    }
}

// Função para carregar cotações (simulação)
function loadQuotes() {
    document.getElementById('coffeePrice').innerText = 'R$ 300,00/saca';
    document.getElementById('ricePrice').innerText = 'R$ 80,00/saca';
}

// Função de login (simulação)
document.getElementById('loginForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    if (username === 'agricultor' && password === '1234') {
        document.getElementById('loginCard').style.display = 'none';
        document.getElementById('dashboard').style.display = 'grid';
        getLocation();
        loadSoilNotes();
        loadQuotes();
        initCalendar();
    } else {
        alert('Usuário ou senha incorretos!');
    }
});

// Inicializa o calendário após o login
initCalendar();